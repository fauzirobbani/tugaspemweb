<?php
include "koneksi.php";
$nama=$_POST['nama'];
$username=$_POST['username'];
$email=$_POST['email'];
$password=$_POST['password'];
$alamat=$_POST['alamat'];
$umur=$_POST['umur'];
$hobi=$_POST['hobi'];
$gender=$_POST['gender'];
$status=$_POST['status'];


$hakakses=$_POST['hakakses'];
$query=mysql_query("insert into pengunjung (nama,gender,alamat,umur,status,hobi,email,username,password,hakakses) 
	values('$nama','$gender',$alamat','$umur','$status','$hobi','$email',$username',md5('$password'),'$hakakses')");
echo "<script>
		alert('Berhasil menambahkan data');
		window.location.assign('login.html');
	</script>";
?>